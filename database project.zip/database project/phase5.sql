CREATE DATABASE coursera;
USE coursera;

CREATE TABLE Student (
    Student_ID INT PRIMARY KEY,
    St_name varchar (50),
    Email VARCHAR(50)
);
ALTER TABLE Student ADD INDEX (St_name);
ALTER TABLE Student
DROP COLUMN Phone_no,
DROP COLUMN Inst_ID,
DROP COLUMN Inst_name;


CREATE TABLE Instructor (
    Instructor_ID INT PRIMARY KEY,
    Email VARCHAR(50),
    Field_ID INT
);
ALTER TABLE Instructor
MODIFY Field_ID VARCHAR(20);

SELECT * FROM Instructor;



CREATE TABLE Program (
    Program_ID INT PRIMARY KEY,
    Field_ID_FK INT
);





CREATE TABLE Field (
    ID INT PRIMARY KEY,
    Name VARCHAR(50)
);
INSERT INTO Field (ID, Name)
VALUES 
    (1, 'Computer Science'),
    (2, 'Engineering'),
    (3, 'Mathematics');

CREATE TABLE Course (
    Course_ID INT PRIMARY KEY,
    CourseName VARCHAR(50),
    CourseSlug varchar(50)
);

CREATE TABLE Enrollment (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50),
    Email VARCHAR(50),
    Enrolled_Courses INT,
    Completed_Courses INT,
    Member_State VARCHAR(50),
    Join_Date DATE,
    Invitation_Date DATE,
    Last_Activity_Time Time
);

CREATE TABLE Address (
    Address_ID INT PRIMARY KEY,
    St_ID INT,
    St_address VARCHAR(50),
    FOREIGN KEY (St_ID) REFERENCES Student(Student_ID)
);

INSERT INTO Address (Address_ID, St_ID, St_address)
VALUES 
    (1, 1, '123 Alexandria Street, Alexandria, Egypt');
    


CREATE TABLE Phone_no (
    Phone_no_ID INT PRIMARY KEY,
    Inst_ID INT,
    Phone_no VARCHAR(20),
    FOREIGN KEY (Inst_ID) REFERENCES Instructor(Instructor_ID)
);

INSERT INTO Phone_no (Phone_no_ID, Inst_ID, Phone_no)
VALUES 
    (1, 4, '+201234567890'),
    (2, 5, '+201234567891'),
    (3, 6, '+201234567892'),
    (4, 7, '+201234567893'),
    (5, 8, '+201234567894'),
    (6, 9, '+201234567895');



CREATE TABLE Has (
    Has_ID INT PRIMARY KEY,
    St_ID INT,
    Program_ID INT,
    FOREIGN KEY (St_ID) REFERENCES Student(Student_ID),
    FOREIGN KEY (Program_ID) REFERENCES Program(Program_ID)
);
INSERT INTO Has (Has_ID, St_ID, Program_ID)
VALUES 
    (1, 1, 1),
    (2, 2, 1),
    (3, 3, 2),
    (4, 1, 2),
    (5, 2, 3),
    (6, 3, 3);


CREATE TABLE Choose (
    Choose_ID INT PRIMARY KEY,
    Inst_ID INT,
    Module_no INT
);
INSERT INTO Choose (Choose_ID, Inst_ID, Module_no)
VALUES 
    (1, 1, 1),
    (2, 1, 2),
    (3, 2, 1),
    (4, 2, 2),
    (5, 3, 1),
    (6, 3, 2);

CREATE TABLE Module (
    Module_ID INT PRIMARY KEY,
    Week_no INT,
    Deadline DATE
);

ALTER TABLE Course ADD UNIQUE (CourseSlug);

CREATE TABLE Have (
    Have_ID INT PRIMARY KEY,
    Module_no INT,
    CourseSlug VARCHAR(50),
    FOREIGN KEY (Module_no) REFERENCES Module(Module_ID),
    FOREIGN KEY (CourseSlug) REFERENCES Course(CourseSlug)
);

CREATE TABLE AIUCourse (
    AIUCourse_ID INT PRIMARY KEY,
    Instructor_ID INT,
    Semester VARCHAR(50),
    ExpectedStudent INT,
    FOREIGN KEY (Instructor_ID) REFERENCES Instructor(Instructor_ID)
);

CREATE TABLE CourseraCourse (
    CourseSlug VARCHAR(50) PRIMARY KEY,
    No_of_hours INT,
    University VARCHAR(50),
    InstructorName VARCHAR(50),
    Report TEXT,
    No_of_finishedStudents INT,
    No_of_weeks INT,
    Specialization VARCHAR(50)
);

CREATE TABLE Project (
    Project_ID INT PRIMARY KEY,
    CourseSlug VARCHAR(50),
    FOREIGN KEY (CourseSlug) REFERENCES CourseraCourse(CourseSlug)
);

CREATE TABLE Inst (
    Inst_ID INT PRIMARY KEY,
    Inst_name VARCHAR(50)
);

CREATE TABLE Admin (
    Admin_ID INT PRIMARY KEY,
    Program_ID INT,
    adminlink VARCHAR(50),
    FOREIGN KEY (Program_ID) REFERENCES Program(Program_ID)
);

CREATE TABLE Learner (
    Learner_ID INT PRIMARY KEY,
    Program_ID INT,
    learnerlink VARCHAR(50),
    FOREIGN KEY (Program_ID) REFERENCES Program(Program_ID)
);

CREATE TABLE St (
    St_ID INT PRIMARY KEY,
    St_name VARCHAR(50)
);

CREATE TABLE TA (
    TA_ID INT PRIMARY KEY,
    Field_ID INT,
    FOREIGN KEY (Field_ID) REFERENCES Field(ID)
);

CREATE TABLE Semester (
    Semester_ID INT PRIMARY KEY,
    Instructor_ID INT,
    Semester VARCHAR(50),
    FOREIGN KEY (Instructor_ID) REFERENCES Instructor(Instructor_ID)
);

CREATE TABLE ExpectedStudent (
    ExpectedStudent_ID INT PRIMARY KEY,
    AIUCourse_ID INT,
    ExpectedStudent INT,
    FOREIGN KEY (AIUCourse_ID) REFERENCES AIUCourse(AIUCourse_ID)
);

CREATE TABLE University (
    University_ID INT PRIMARY KEY,
    CourseraCourse_CourseSlug VARCHAR(50),
    University VARCHAR(50),
    FOREIGN KEY (CourseraCourse_CourseSlug) REFERENCES CourseraCourse(CourseSlug)
);

CREATE TABLE InstructorName (
    InstructorName_ID INT PRIMARY KEY,
    CourseraCourse_CourseSlug VARCHAR(50),
    InstructorName VARCHAR(50),
    FOREIGN KEY (CourseraCourse_CourseSlug) REFERENCES CourseraCourse(CourseSlug)
);

CREATE TABLE Report (
    Report_ID INT PRIMARY KEY,
    CourseraCourse_CourseSlug VARCHAR(50),
    Report TEXT,
    FOREIGN KEY (CourseraCourse_CourseSlug) REFERENCES CourseraCourse(CourseSlug)
);

CREATE TABLE No_of_finishedStudents (
    No_of_finishedStudents_ID INT PRIMARY KEY,
    CourseraCourse_CourseSlug VARCHAR(50),
    No_of_finishedStudents INT,
    FOREIGN KEY (CourseraCourse_CourseSlug) REFERENCES CourseraCourse(CourseSlug)
);

CREATE TABLE No_of_weeks (
    No_of_weeks_ID INT PRIMARY KEY,
    CourseraCourse_CourseSlug VARCHAR(50),
    No_of_weeks INT,
    FOREIGN KEY (CourseraCourse_CourseSlug) REFERENCES CourseraCourse(CourseSlug)
);

CREATE TABLE Specialization (
    Specialization_ID INT PRIMARY KEY,
    CourseraCourse_CourseSlug VARCHAR(50),
    Specialization VARCHAR(50),
    FOREIGN KEY (CourseraCourse_CourseSlug) REFERENCES CourseraCourse(CourseSlug)
);

INSERT INTO Student (
    Student_ID,
    St_name,
    Email
) VALUES (
    1,
    'omar',
    'example'
);
INSERT INTO Instructor (Instructor_ID, Email, Field_ID)
VALUES 
    (1, 'instructor1@example.com', 'field1'),
    (2, 'instructor2@example.com', 'field2'),
    (3, 'instructor3@example.com', 'field3');
-- Insert 6 rows into the Module table
INSERT INTO Module (Module_ID, Week_no, Deadline)
VALUES 
    (1, 1, '2024-04-30'),
    (2, 2, '2024-05-07'),
    (3, 3, '2024-05-14'),
    (4, 4, '2024-05-21'),
    (5, 5, '2024-05-28'),
    (6, 6, '2024-06-04');

INSERT INTO Program (Program_ID, Field_ID_FK)
VALUES 
    (1, 123),
    (2, 456),
    (3, 789);
-- Insert 6 rows into the Have table
INSERT INTO Have (Have_ID, Module_no, CourseSlug)
VALUES 
    (1, 1, 'intro-to-programming'),
    (2, 2, 'intro-to-programming'),
    (3, 3, 'data-structures-algorithms'),
    (4, 4, 'data-structures-algorithms'),
    (5, 5, 'database-management-systems'),
    (6, 6, 'database-management-systems');

INSERT INTO Course (Course_ID, CourseName, CourseSlug)
VALUES 
    (1, 'Introduction to Programming', 'intro-to-programming'),
    (2, 'Data Structures and Algorithms', 'data-structures-algorithms'),
    (3, 'Database Management Systems', 'database-management-systems');

-- Insert 6 rows into the AIUCourse table
INSERT INTO AIUCourse (AIUCourse_ID, Instructor_ID, Semester, ExpectedStudent)
VALUES 
    (1, 1, 'Spring 2024', 50),
    (2, 2, 'Spring 2024', 60),
    (3, 3, 'Spring 2024', 70),
    (4, 4, 'Fall 2024', 55),
    (5, 5, 'Fall 2024', 65),
    (6, 6, 'Fall 2024', 75),
	(14, 7, 'Spring 2024', 50),
    (8, 8, 'Spring 2024', 60),
    (9, 9, 'Spring 2024', 70),
    (10, 10, 'Fall 2024', 55),
    (11, 12, 'Fall 2024', 65),
    (12, 13, 'Fall 2024', 75);
    
    INSERT INTO Enrollment (Student_ID, Name, Email, Enrolled_Courses, Completed_Courses, Member_State, Join_Date, Invitation_Date, Last_Activity_Time)
VALUES 
(23101577, 'Abdelrahman Mohamed Ahmad Mohamed Ahmad', 'abdelrahman.ahmad.2024@aiu.edu.eg', 2, 2, 'MEMBER', '2023-10-13 11:33:33', '2023-10-12 21:54:25', '2023-12-07 15:28:10'),
(23101506, 'Yomna Mohamed Fekry Hosney Mohamed Elmenawy', 'yomna.hosney.2024@aiu.edu.eg', 2, 2, 'MEMBER', '2023-10-18 17:50:02', '2023-10-12 21:54:27', '2023-12-10 13:42:10'),
(22100497, 'Youssef Shaaban Muhammad Qutb', 'youssef.qutb.2023@Aiu.edu.eg', 0, 0, 'MEMBER', '2023-10-01 07:27:04', '2022-10-30 17:43:20', '2023-04-28 13:38:58'),
(21100447, 'Amir mohamed Ahmed Abdelkader', 'amir.abdelkader.2022@Aiu.edu.eg', 6, 1, 'MEMBER', '2023-10-01 07:35:02', '2021-12-25 19:57:42', '2023-12-14 07:01:19'),
(22100578, 'Maryam Gomaa Gomaa Ahmed', 'maryam.gomaa.2023@Aiu.edu.eg', 7, 7, 'DELETED_MEMBER', '2023-10-01 07:27:35', '2023-11-25 16:54:00', NULL),
(22101912, 'Raghad Mohamed Ahmed Mohamed AbuRafai', 'raghad.mohamed.2023@Aiu.edu.eg', 6, 4, 'DELETED_MEMBER', '2023-10-01 07:38:00', '2023-11-20 13:51:08', NULL),
(23102385, 'Menna Abdo Saeed Ahmed', 'menna.saeed.2024@aiu.edu.eg', 2, 2, 'DELETED_MEMBER', '2023-10-19 08:43:30', '2023-12-03 17:48:09', NULL),
(20100257, 'Mostafa Ibrahem Mostafa Elsayid Hasona', 'mostafa.hasona@Aiu.edu.eg', 7, 0, 'MEMBER', '2023-10-01 07:29:05', '2021-10-24 10:06:51', '2023-08-28 22:19:39'),
(23101364, 'Adham Ashraf Nagy Helmy Ahmed Gomaa', 'adham.helmy.2024@aiu.edu.eg', 2, 1, 'MEMBER', '2023-10-13 11:06:08', '2023-10-12 21:54:27', '2023-12-13 19:15:48'),
(22101295, 'Hussain Mahmoud Hussain Mahmoud Gozlan', 'hussain.gozlan.2023@Aiu.edu.eg', 0, 0, 'MEMBER', '2023-10-01 07:30:47', '2022-10-30 17:43:20', '2023-04-29 19:28:57'),
(20100384, 'Israa Wael Wageh Mohamed Aly', 'esraa.wael@Aiu.edu.eg', 10, 1, 'MEMBER', '2023-10-01 07:38:53', '2021-10-24 10:06:51', '2023-12-12 13:04:35'),
(21100852, 'Maged Khaled Mohammed abohamed', 'maged.abohamed.2022@Aiu.edu.eg', 1, 0, 'MEMBER', '2023-10-01 07:28:04', '2021-10-24 12:17:01', '2023-05-01 21:50:08'),
(23101593, 'Mohamed Essam Mohamed Abdo', 'mohamed.abdo.2024@aiu.edu.eg', 1, 0, 'MEMBER', '2023-11-01 18:16:06', '2023-10-12 21:54:29', '2023-12-03 17:40:45'),
(22101299, 'Abdallah Saleh Safy Saleh', 'abdallah.saleh.2023@Aiu.edu.eg', 1, 0, 'MEMBER', '2023-10-01 07:31:29', '2022-10-30 17:43:20', '2022-12-24 21:41:49')
;


-- Insert 6 rows into the CourseraCourse table
INSERT INTO CourseraCourse (CourseSlug, No_of_hours, University, InstructorName, Report, No_of_finishedStudents, No_of_weeks, Specialization)
VALUES 
    ('intro-to-programming', 40, 'Coursera University', 'John Doe', 'Excellent', 2000, 6, 'Programming'),
    ('data-structures-algorithms', 60, 'Coursera University', 'Jane Smith', 'Good', 1500, 8, 'Algorithms'),
    ('database-management-systems', 50, 'Coursera University', 'Alice Johnson', 'Very Good', 1800, 7, 'Database');

-- Insert 6 rows into the Project table
INSERT INTO Project (Project_ID, CourseSlug)
VALUES 
    (1, 'intro-to-programming'),
    (2, 'data-structures-algorithms'),
    (3, 'database-management-systems'),
    (4, 'intro-to-programming'),
    (5, 'data-structures-algorithms'),
    (6, 'database-management-systems');

-- Insert 6 rows into the Inst table
INSERT INTO Inst (Inst_ID, Inst_name)
VALUES 
    (1, 'Institute 1'),
    (2, 'Institute 2'),
    (3, 'Institute 3');

-- Insert 6 rows into the Admin table
INSERT INTO Admin (Admin_ID, Program_ID, adminlink)
VALUES 
    (1, 1, 'adminlink1'),
    (2, 1, 'adminlink2'),
    (3, 2, 'adminlink3'),
    (4, 2, 'adminlink4'),
    (5, 3, 'adminlink5'),
    (6, 3, 'adminlink6');

-- Insert 6 rows into the Learner table
INSERT INTO Learner (Learner_ID, Program_ID, learnerlink)
VALUES 
    (1, 1, 'learnerlink1'),
    (2, 1, 'learnerlink2'),
    (3, 2, 'learnerlink3'),
    (4, 2, 'learnerlink4'),
    (5, 3, 'learnerlink5'),
    (6, 3, 'learnerlink6');

-- Insert 6 rows into the St table
INSERT INTO St (St_ID, St_name)
VALUES 
    (1, 'Student 1'),
    (2, 'Student 2'),
    (3, 'Student 3'),
    (4, 'Student 4'),
    (5, 'Student 5'),
    (6, 'Student 6');

-- Insert 6 rows into the TA table
INSERT INTO TA (TA_ID, Field_ID)
VALUES 
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 1),
    (5, 2),
    (6, 3);

-- Insert 6 rows into the Semester table
INSERT INTO Semester (Semester_ID, Instructor_ID, Semester)
VALUES 
    (1, 1, 'Spring 2024'),
    (2, 1, 'Spring 2024'),
    (3, 2, 'Spring 2024'),
    (4, 2, 'Spring 2024'),
    (5, 3, 'Spring 2024'),
    (6, 3, 'Spring 2024');

-- Insert 6 rows into the ExpectedStudent table
INSERT INTO ExpectedStudent (ExpectedStudent_ID, AIUCourse_ID, ExpectedStudent)
VALUES 
    (1, 1, 50),
    (2, 2, 60),
    (3, 3, 70),
    (4, 1, 55),
    (5, 2, 65),
    (6, 3, 75);

-- Insert 6 rows into the University table
INSERT INTO University (University_ID, CourseraCourse_CourseSlug, University)
VALUES 
    (1, 'intro-to-programming', 'University 1'),
    (2, 'data-structures-algorithms', 'University 2'),
    (3, 'database-management-systems', 'University 3');

-- Insert 6 rows into the InstructorName table
INSERT INTO InstructorName (InstructorName_ID, CourseraCourse_CourseSlug, InstructorName)
VALUES 
    (1, 'intro-to-programming', 'John Doe'),
    (2, 'data-structures-algorithms', 'Jane Smith'),
    (3, 'database-management-systems', 'Alice Johnson');

-- Insert 6 rows into the Report table
INSERT INTO Report (Report_ID, CourseraCourse_CourseSlug, Report)
VALUES 
    (1, 'intro-to-programming', 'Excellent'),
    (2, 'data-structures-algorithms', 'Good'),
    (3, 'database-management-systems', 'Very Good');

-- Insert 6 rows into the No_of_finishedStudents table
INSERT INTO No_of_finishedStudents (No_of_finishedStudents_ID, CourseraCourse_CourseSlug, No_of_finishedStudents)
VALUES 
    (1, 'intro-to-programming', 2000),
    (2, 'data-structures-algorithms', 1500),
    (3, 'database-management-systems', 1800);

-- Insert 6 rows into the No_of_weeks table
INSERT INTO No_of_weeks (No_of_weeks_ID, CourseraCourse_CourseSlug, No_of_weeks)
VALUES 
    (1, 'intro-to-programming', 6),
    (2, 'data-structures-algorithms', 8),
    (3, 'database-management-systems', 7);

-- Insert 6 rows into the Specialization table
INSERT INTO Specialization (Specialization_ID, CourseraCourse_CourseSlug, Specialization)
VALUES 
    (1, 'intro-to-programming', 'Programming'),
    (2, 'data-structures-algorithms', 'Algorithms'),
    (3, 'database-management-systems', 'Database');
    
#List courses along with the number of enrolled students:
SELECT c.CourseName, COUNT(e.Student_ID) AS Enrolled_Students
FROM Course c
JOIN Enrollment e ON c.Course_ID = e.Enrolled_Courses
GROUP BY c.CourseName;


#Get a list of students who have not completed any courses:
SELECT *
FROM Enrollment
WHERE Completed_Courses = 0;


#Find the average number of hours per course in each specialization:
SELECT cc.Specialization, AVG(cc.No_of_hours) AS AverageHours
FROM CourseraCourse cc
GROUP BY cc.Specialization;

#Find the total number of students for each instructor:
SELECT i.Instructor_ID, i.Email, COUNT(s.Student_ID) AS Total_Students
FROM Instructor i
JOIN AIUCourse a ON i.Instructor_ID = a.Instructor_ID
JOIN Enrollment e ON a.AIUCourse_ID = e.Enrolled_Courses
JOIN Student s ON e.Student_ID = s.Student_ID
GROUP BY i.Instructor_ID;

#Show courses that have not been completed by any student:
SELECT c.CourseName
FROM Course c
LEFT JOIN Enrollment e ON c.Course_ID = e.Completed_Courses
WHERE e.Student_ID IS NULL;

#Find instructors who teach more than one course:
SELECT i.Instructor_ID, i.Email, COUNT(a.AIUCourse_ID) AS Courses_Taught
FROM Instructor i
JOIN AIUCourse a ON i.Instructor_ID = a.Instructor_ID
GROUP BY i.Instructor_ID
HAVING COUNT(a.AIUCourse_ID) > 1;


#Retrieve all students who have completed a certain course
SELECT Student.Student_ID, Student.St_name, Enrollment.Completed_Courses, Course.CourseName
FROM Student
INNER JOIN Enrollment ON Student.Student_ID = Enrollment.Student_ID
INNER JOIN Course ON Enrollment.Completed_Courses = Course.Course_ID
WHERE Course.CourseName = 'Introduction to Programming';


# Find the total number of enrolled students in each course

SELECT Course.CourseName, COUNT(Enrollment.Student_ID) AS Enrolled_Students
FROM Course
LEFT JOIN Have ON Course.CourseSlug = Have.CourseSlug
LEFT JOIN Module ON Have.Module_no = Module.Module_ID
LEFT JOIN Enrollment ON Module.Module_ID = Enrollment.Enrolled_Courses
GROUP BY Course.CourseName;


-- Creating Views

CREATE VIEW View_EnrolledStudentsPerCourse AS
SELECT c.CourseName, COUNT(e.Student_ID) AS Enrolled_Students
FROM Course c
JOIN Enrollment e ON c.Course_ID = e.Enrolled_Courses
GROUP BY c.CourseName;

CREATE VIEW View_StudentsWithNoCompletion AS
SELECT *
FROM Enrollment
WHERE Completed_Courses = 0;

CREATE VIEW View_AverageHoursPerSpecialization AS
SELECT cc.Specialization, AVG(cc.No_of_hours) AS AverageHours
FROM CourseraCourse cc
GROUP BY cc.Specialization;

CREATE VIEW View_TotalStudentsPerInstructor AS
SELECT i.Instructor_ID, i.Email, COUNT(s.Student_ID) AS Total_Students
FROM Instructor i
JOIN AIUCourse a ON i.Instructor_ID = a.Instructor_ID
JOIN Enrollment e ON a.AIUCourse_ID = e.Enrolled_Courses
JOIN Student s ON e.Student_ID = s.Student_ID
GROUP BY i.Instructor_ID;

CREATE VIEW View_UncompletedCourses AS
SELECT c.CourseName
FROM Course c
LEFT JOIN Enrollment e ON c.Course_ID = e.Completed_Courses
WHERE e.Student_ID IS NULL;

CREATE VIEW View_MultiCourseInstructors AS
SELECT i.Instructor_ID, i.Email, COUNT(a.AIUCourse_ID) AS Courses_Taught
FROM Instructor i
JOIN AIUCourse a ON i.Instructor_ID = a.Instructor_ID
GROUP BY i.Instructor_ID
HAVING COUNT(a.AIUCourse_ID) > 1;

CREATE VIEW View_CompletedProgrammingCourse AS
SELECT Student.Student_ID, Student.St_name, Enrollment.Completed_Courses, Course.CourseName
FROM Student
INNER JOIN Enrollment ON Student.Student_ID = Enrollment.Student_ID
INNER JOIN Course ON Enrollment.Completed_Courses = Course.Course_ID
WHERE Course.CourseName = 'Introduction to Programming';

CREATE VIEW View_TotalEnrolledStudentsPerCourse AS
SELECT Course.CourseName, COUNT(Enrollment.Student_ID) AS Enrolled_Students
FROM Course
LEFT JOIN Have ON Course.CourseSlug = Have.CourseSlug
LEFT JOIN Module ON Have.Module_no = Module.Module_ID
LEFT JOIN Enrollment ON Module.Module_ID = Enrollment.Enrolled_Courses
GROUP BY Course.CourseName;

-- Creating Stored Procedures

DELIMITER //
CREATE PROCEDURE GetEnrolledStudentsPerCourse()
BEGIN
    SELECT * FROM View_EnrolledStudentsPerCourse;
END //
DELIMITER //

DELIMITER //
CREATE PROCEDURE GetStudentsWithNoCompletion()
BEGIN
    SELECT * FROM View_StudentsWithNoCompletion;
END //
DELIMITER //

DELIMITER //
CREATE PROCEDURE GetAverageHoursPerSpecialization()
BEGIN
    SELECT * FROM View_AverageHoursPerSpecialization;
END //
DELIMITER //

DELIMITER //
CREATE PROCEDURE GetTotalStudentsPerInstructor()
BEGIN
    SELECT * FROM View_TotalStudentsPerInstructor;
END //
DELIMITER //

DELIMITER //
CREATE PROCEDURE GetUncompletedCourses()
BEGIN
    SELECT * FROM View_UncompletedCourses;
END //
DELIMITER //

DELIMITER //
CREATE PROCEDURE GetMultiCourseInstructors()
BEGIN
    SELECT * FROM View_MultiCourseInstructors;
END //
DELIMITER //

DELIMITER //
CREATE PROCEDURE GetCompletedProgrammingCourse()
BEGIN
    SELECT * FROM View_CompletedProgrammingCourse;
END //
DELIMITER //

DELIMITER //
CREATE PROCEDURE GetTotalEnrolledStudentsPerCourse()
BEGIN
    SELECT * FROM View_TotalEnrolledStudentsPerCourse;
END //
DELIMITER //
